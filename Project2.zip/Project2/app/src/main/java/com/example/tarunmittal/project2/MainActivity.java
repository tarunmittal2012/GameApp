package com.example.tarunmittal.project2;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button mButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mButton = (Button) findViewById(R.id.play);
    }

    public void play(View view) {
        final AlertDialog.Builder ab1 = new AlertDialog.Builder(MainActivity.this);
        ab1.setTitle(R.string.dialogtitle);

        ab1.setMessage(R.string.DialogMessage);
        View v1 = getLayoutInflater().inflate(R.layout.customdialog, null);
        ab1.setView(v1);
        ab1.setPositiveButton(R.string.positivebutton, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent i = new Intent(MainActivity.this, PlayGame.class);
                startActivity(i);
            }
        });
        ab1.setNegativeButton(R.string.negativebutton, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        ab1.show();
    }
}
