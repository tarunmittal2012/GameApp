package com.example.tarunmittal.project2;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;
import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class PlayGame extends AppCompatActivity {


    CountDownTimer mCountDownTimer;
    int scoreCardA = 0;
    int scoreCardB = 0;
    int wicketCardA = 0;
    int wicketCardB = 0;
    long millis;
    @BindView(R.id.score1A)
    Button run1A;
    @BindView(R.id.score1B)
    Button run1B;
    @BindView(R.id.score2A)
    Button run2A;
    @BindView(R.id.score2B)
    Button run2B;
    @BindView(R.id.score4A)
    Button run4A;
    @BindView(R.id.score4B)
    Button run4B;
    @BindView(R.id.score6A)
    Button run6A;
    @BindView(R.id.score6B)
    Button run6B;
    @BindView(R.id.wicketA)
    Button wicktA;
    @BindView(R.id.wicketB)
    Button wicktB;
    @BindView(R.id.totalScoreA)
    TextView totScoreA;
    @BindView(R.id.totalScoreB)
    TextView totScoreB;
    @BindView(R.id.totalWicketA)
    TextView totWicketA;
    @BindView(R.id.totalWicketB)
    TextView totWicketB;
    @BindView(R.id.layout)
    LinearLayout mLinearLayout;
    @BindView(R.id.starttime)
    TextView timeText;
    @BindView(R.id.starttimetext1)
    TextView startTimetext1;
    @BindView(R.id.play1)
    Button play;
    @BindView(R.id.reset)
    Button reset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_play_game);
        ButterKnife.bind(this);
    }

    @OnClick(R.id.score1A)
    void run1A(View view) {
        scoreCardA++;
        displayA(scoreCardA);
    }

    @OnClick(R.id.score1B)
    void run1B(View view) {
        scoreCardB++;
        displayB(scoreCardB);
    }

    @OnClick(R.id.score2A)
    void run2A(View view) {
        scoreCardA += 2;
        displayA(scoreCardA);
    }

    @OnClick(R.id.score2B)
    void run2B(View view) {
        scoreCardB += 2;
        displayB(scoreCardB);
    }

    @OnClick(R.id.score4A)
    void run4A(View view) {
        scoreCardA += 4;
        displayA(scoreCardA);
    }

    @OnClick(R.id.score4B)
    void run4B(View view) {
        scoreCardB += 4;
        displayB(scoreCardB);
    }

    @OnClick(R.id.score6A)
    void run6A(View view) {
        scoreCardA += 6;
        displayA(scoreCardA);
    }

    @OnClick(R.id.score6B)
    void run6B(View view) {
        scoreCardB += 6;
        displayB(scoreCardB);
    }

    @OnClick(R.id.wicketA)
    void wicketA(View view) {
        if (wicketCardA < 10) {
            wicketCardA += 1;
            displayWicketA(wicketCardA);
        }
        if (wicketCardA == 10) {
            run1A.setEnabled(false);
            run2A.setEnabled(false);
            run4A.setEnabled(false);
            run6A.setEnabled(false);
            wicktA.setEnabled(false);
            Toast.makeText(PlayGame.this, R.string.toastMessage, Toast.LENGTH_LONG).show();
        }

    }

    @OnClick(R.id.wicketB)
    void wicketB(View view) {
        if (wicketCardB < 10) {
            wicketCardB += 1;
            displayWicketB(wicketCardB);

        }
        if (wicketCardB == 10) {
            run1B.setEnabled(false);
            run2B.setEnabled(false);
            run4B.setEnabled(false);
            run6B.setEnabled(false);
            wicktB.setEnabled(false);
            Toast.makeText(PlayGame.this, R.string.toastMessage, Toast.LENGTH_LONG).show();

        }
        if (wicketCardA == 10 && wicketCardB == 10) {
            mCountDownTimer.onFinish();
        }
    }

    private void displayA(int scoreCardA) {

        totScoreA.setText(String.valueOf(scoreCardA));

    }

    @OnClick(R.id.play1)
    void play1(View view) {
        play.setVisibility(View.GONE);
        reset.setVisibility(View.VISIBLE);
        timeText.setVisibility(View.VISIBLE);
        startTimetext1.setVisibility(View.VISIBLE);
        mLinearLayout.setVisibility(View.VISIBLE);
        mCountDownTimer = new CountDownTimer(300000, 1000) {
            public void onTick(long millisUntilFinished) {
                millis = millisUntilFinished;
                String text = String.format(Locale.getDefault(), "Time Left %02d min: %02d sec",
                        TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished) % 60,
                        TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) % 60);
                timeText.setText(text);
            }

            public void onFinish() {

                int totalTeam1Score = Integer.parseInt(totScoreA.getText().toString());
                int totalTeam2Score = Integer.parseInt(totScoreB.getText().toString());
                AlertDialog.Builder builder = new AlertDialog.Builder(PlayGame.this);

                if (totalTeam1Score > totalTeam2Score) {
                    builder.setTitle(R.string.Congratulation);
                    builder.setMessage(R.string.winMessage);
                } else if (totalTeam1Score == totalTeam2Score) {
                    builder.setTitle(R.string.Congratulation);
                    builder.setMessage(R.string.winMessagec);
                } else {
                    builder.setTitle(R.string.Congratulation);
                    builder.setMessage(R.string.winMessageB);
                }
                builder.setPositiveButton("Finish", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent i = new Intent(PlayGame.this, MainActivity.class);
                        startActivity(i);
                    }
                }).show();
            }
        }.start();

    }

    @OnClick(R.id.reset)
    void resetgame(View view) {
        scoreCardA = 0;
        scoreCardB = 0;
        wicketCardA = 0;
        wicketCardB = 0;
        displayA(scoreCardA);
        displayWicketA(wicketCardA);
        displayB(scoreCardB);
        displayWicketB(wicketCardB);
        if (mCountDownTimer != null) {
            mCountDownTimer.cancel();
            mCountDownTimer.start();
        }

    }

    public void displayWicketB(int wicketCardB) {
        totWicketB.setText(String.valueOf(wicketCardB));
    }

    private void displayB(int scoreCardB) {
        totScoreB.setText(String.valueOf(scoreCardB));
    }

    private void displayWicketA(int wicketCardA) {
        totWicketA.setText(String.valueOf(wicketCardA));
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        CharSequence team1Scoretext = totScoreA.getText();
        CharSequence team2Scoretext = totScoreB.getText();
        outState.putCharSequence("SCORE", team1Scoretext);
        outState.putCharSequence("SCORE1", team2Scoretext);

        outState.putLong("time", millis);

    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        totScoreA.setText(savedInstanceState.getCharSequence("SCORE"));
        totScoreB.setText(savedInstanceState.getCharSequence("SCORE1"));
        millis = savedInstanceState.getLong("time");
    }

}
